import 'dart:convert';
import 'dart:math';

import 'package:dio/dio.dart';
import 'package:iot_app/models/data.dart';

class APIService{
  late Dio dio;

  APIService(){
    dio = Dio();
  }

  Future<Data> getData({int limit = 1}) async{
    var response = await dio.get('https://api.thingspeak.com/channels/1821816/feeds.json?results=$limit');
    final data = Data.fromJson(response.data);
    return data;
  }

  Future<void> updateData() async{
    final random = Random();
    final temp = random.nextInt(100);
    final hum = random.nextInt(100);
    await dio.get('https://api.thingspeak.com/update?api_key=2VDF3KLIU8KIPBME&field1=$temp&field2=$hum');
  }

}