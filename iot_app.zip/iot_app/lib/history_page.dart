import 'package:flutter/material.dart';
import 'package:iot_app/models/feed.dart';
import 'package:iot_app/service/api_service.dart';
import 'package:collection/collection.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final service = APIService();

  var tempLabel = '';
  var humLabel = '';

  var feeds = [];

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Histories'),
        centerTitle: true,
      ),
      body: ListView.separated(
        padding: EdgeInsets.symmetric(horizontal: 16),
        itemBuilder: (context, index) {
          final feed = feeds[index];
          return buildItem(feed);
        },
        separatorBuilder: (_, __) => const Divider(),
        itemCount: feeds.length,
      ),
    );
  }

  Widget buildItem(Feed feed){
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text('Created date: ${feed.createdAt}', style: Theme.of(context).textTheme.caption,),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$tempLabel:  ',
                style:
                const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              Text(
                feed.field1 ?? '',
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.green),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$humLabel:  ',
                style:
                const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              Text(
                feed.field2 ?? '',
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.green),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getData() {
    service.getData(limit: 10).then((value) {
      setState(() {
        tempLabel = value.channel?.field1 ?? '';
        humLabel = value.channel?.field2 ?? '';

        feeds.clear();
        feeds.addAll(value.feeds ?? []);
      });
    }).catchError((e) {
      print('error: $e');
    });
  }
}
