class Feed {
  Feed({
    this.createdAt,
    this.entryId,
    this.field1,
    this.field2,});

  Feed.fromJson(dynamic json) {
    createdAt = json['created_at'];
    entryId = json['entry_id'];
    field1 = json['field1'];
    field2 = json['field2'];
  }
  String? createdAt;
  int? entryId;
  String? field1;
  String? field2;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['created_at'] = createdAt;
    map['entry_id'] = entryId;
    map['field1'] = field1;
    map['field2'] = field2;
    return map;
  }

}