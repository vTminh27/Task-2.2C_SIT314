import 'channel.dart';
import 'feed.dart';

class Data {
  Data({
      this.channel, 
      this.feeds,});

  Data.fromJson(dynamic json) {
    channel = json['channel'] != null ? Channel.fromJson(json['channel']) : null;
    if (json['feeds'] != null) {
      feeds = [];
      json['feeds'].forEach((v) {
        feeds?.add(Feed.fromJson(v));
      });
    }
  }
  Channel? channel;
  List<Feed>? feeds;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (channel != null) {
      map['channel'] = channel?.toJson();
    }
    if (feeds != null) {
      map['feeds'] = feeds?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}