class Channel {
  Channel({
    this.id,
    this.name,
    this.latitude,
    this.longitude,
    this.field1,
    this.field2,
    this.createdAt,
    this.updatedAt,
    this.lastEntryId,});

  Channel.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    field1 = json['field1'];
    field2 = json['field2'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    lastEntryId = json['last_entry_id'];
  }
  int? id;
  String? name;
  String? latitude;
  String? longitude;
  String? field1;
  String? field2;
  String? createdAt;
  String? updatedAt;
  int? lastEntryId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['latitude'] = latitude;
    map['longitude'] = longitude;
    map['field1'] = field1;
    map['field2'] = field2;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['last_entry_id'] = lastEntryId;
    return map;
  }

}