import 'package:flutter/material.dart';
import 'package:iot_app/history_page.dart';
import 'package:iot_app/service/api_service.dart';
import 'package:collection/collection.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final service = APIService();

  var tempLabel = '';
  var tempValue = '';

  var humLabel = '';
  var humValue = '';

  var createdDate = '';

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('IOT App'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const HistoryPage()));
            },
            icon: const Icon(Icons.history),
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '$tempLabel:  ',
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              ),
              Text(
                tempValue,
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.green),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '$humLabel:  ',
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              ),
              Text(
                humValue,
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.green),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'Created date: $createdDate',
            style: Theme.of(context).textTheme.caption,
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: () async{
              getData();
            },
            child: const Text('Refresh'),
          ),
        ],
      ),
    );
  }

  void getData() {
    service.getData().then((value) {
      setState(() {
        tempLabel = value.channel?.field1 ?? '';
        humLabel = value.channel?.field2 ?? '';

        final feed = value.feeds?.firstOrNull;
        if (feed != null) {
          tempValue = feed.field1 ?? '';
          humValue = feed.field2 ?? '';
          createdDate = feed.createdAt ?? '';
        }
      });
    }).catchError((e) {
      print('error: $e');
    });
  }
}
