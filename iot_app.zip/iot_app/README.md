# iot_app

A new IOT project.

## Getting Started

flutter clean
flutter pub get
flutter build apk